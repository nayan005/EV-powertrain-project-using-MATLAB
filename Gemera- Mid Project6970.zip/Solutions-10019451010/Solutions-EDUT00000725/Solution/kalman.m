% Define the parameters for two separate Kalman filters
params = [
    struct('measurement_noise', 20, 'initial_position', 4000, ...
           'position_error', 20, 'initial_speed', 90, ...
           'speed_error', 5, 'sampling_period', 0.1),
    struct('measurement_noise', 1.5, 'initial_position', 3000, ...
           'position_error', 10, 'initial_speed', 110, ...
           'speed_error', 2, 'sampling_period', 0.02)
];

% I've increased the measurement noise (measurement noise), initial position error (position error), 
% and speed error (speed error) for both sets of parameters to simulate changes that could occur in real life, 
% such as worse sensor performance or more uncertain initial conditions.

% params = [
%     struct('measurement_noise', 30, 'initial_position', 4000, ... % Increased measurement noise
%            'position_error', 40, 'initial_speed', 90, ... % Increased initial position error
%            'speed_error', 10, 'sampling_period', 0.1), % Increased speed error
%     struct('measurement_noise', 2.5, 'initial_position', 3000, ... % Slightly increased measurement noise
%            'position_error', 15, 'initial_speed', 110, ... % Increased initial position error
%            'speed_error', 3, 'sampling_period', 0.02) % Increased speed error
% ];






% Number of measurements
N = 100;

% Measurements with noise for the first set
measurements1 = params(1).initial_position - (1:N)' * params(1).initial_speed * params(1).sampling_period ...
                + params(1).measurement_noise * randn(N, 1);

% Measurements with noise for the second set
measurements2 = params(2).initial_position - (1:N)' * params(2).initial_speed * params(2).sampling_period ...
                + params(2).measurement_noise * randn(N, 1);

% Variables to store true state, estimates, and measurements for plotting
true_state = zeros(N, 2, length(params));
estimates = zeros(N, 2, length(params));
measurements = zeros(N, length(params));

% Run the Kalman filter for each set of parameters
for p = 1:length(params)
    param = params(p);

    % Define the sampling period
    dt = param.sampling_period;

    % State transition matrix A (assuming constant velocity model)
    A = [1 dt; 0 1];

    % Measurement matrix H
    H = [1 0];

    % Process noise covariance Q (assuming the process noise is small)
    Q = [0.0001 0; 0 0.0001];

    % Measurement noise covariance R
    R = param.measurement_noise^2;

    % Initial state estimate and covariance
    x = [param.initial_position; param.initial_speed];
    P = diag([param.position_error^2, param.speed_error^2]);

    % Placeholder for true state and Kalman filter estimates
    true_state(:, :, p) = [params(p).initial_position - (1:N)' * params(p).initial_speed * params(p).sampling_period, ...
                           repmat(params(p).initial_speed, N, 1)];
    estimates_k = zeros(N, 2);
    if p == 1
        measurements(:, p) = measurements1;
    else
        measurements(:, p) = measurements2;
    end

    % Kalman Filter Implementation
    for k = 1:numel(measurements(:, p))
        % Time Update (Predict)
        x = A * x;
        P = A * P * A' + Q;

        % Measurement Update (Correct)
        z = measurements(k, p); % Synthetic measurement
        y = z - H * x; % Measurement residual
        S = H * P * H' + R; % Residual covariance
        K = P * H' / S; % Kalman gain
        x = x + K * y; % Updated state estimate
        P = (eye(2) - K * H) * P; % Updated estimate covariance

        % Store the estimates
        estimates_k(k, :) = x';
    end
    estimates(:, :, p) = estimates_k;

    % Display the final state estimate for this set of parameters
    fprintf('Final position estimate for set %d: %.2f\n', p, x(1));
    fprintf('Final speed estimate for set %d: %.2f\n', p, x(2));
end

% Plotting and Saving Figures
for p = 1:length(params)
    % Position Plot
    figure;
    plot(1:N, true_state(:, 1, p), 'g', 1:N, measurements(:, p), 'r', 1:N, estimates(:, 1, p), 'b');
    legend('True Position', 'Measurements', 'Kalman Estimate');
    xlabel('Time Step');
    ylabel('Position');
    title(sprintf('Position Estimates for Set %d', p));
    saveas(gcf, sprintf('Position_Set_%d.png', p)); % Save the position plot

    % Velocity Plot
    figure;
    plot(1:N, true_state(:, 2, p), 'g', 1:N, estimates(:, 2, p), 'b');
    legend('True Velocity', 'Kalman Estimate');
    xlabel('Time Step');
    ylabel('Velocity');
    title(sprintf('Velocity Estimates for Set %d', p));
    saveas(gcf, sprintf('Velocity_Set_%d.png', p)); % Save the velocity plot
end
